const { scrapeCitiesOfPunjab } = require('./Scrape/scrapeCitiesOfPunjab');
const { scrapeCitiesOfSindh } = require('./Scrape/scrapeCitiesOfSindh');
const { scrapeCitiesOfBalochistan } = require('./Scrape/scrapeCitiesOfBalochistan');
const { storeInCSVFile } = require('./CSV/storeInCSVFile');
const { request } = require('http');

scrapeCitiesOfPunjab().then(
    (cities) => {
        storeInCSVFile(cities, 'Punjab_Cities.csv');
    }
);

scrapeCitiesOfSindh().then(
    (cities) => {
        storeInCSVFile(cities, 'Sindh_Cities.csv');
    }
);
scrapeCitiesOfBalochistan().then(
    (cities) => {
        storeInCSVFile(cities, 'Balochistan_Cities.csv');
    }
);