const { createCSVObjectArray } = require('./createCSVObject');

// this places commas with token in csvObject
const placeCommas = (csvObject, token) => {
    return csvObject.replace(new RegExp(`${token}`, 'g'), ',');
}
// this stores array of cities in csv file
const storeInCSVFile = (citiesArray, fileName) => {
    const CSVObject = createCSVObjectArray(citiesArray);
    const placeComma = placeCommas(CSVObject);
    const fs = require('fs');
    fs.writeFile(__dirname + '/../' +  fileName, placeComma, () => {});
}
exports.storeInCSVFile = storeInCSVFile;