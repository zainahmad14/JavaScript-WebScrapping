const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');

const url = 'https://en.wikipedia.org/wiki/List_of_cities_in_Balochistan,_Pakistan_by_population';

// this scrape cities of balochistan 
// store them in array 
const scrapeCitiesOfBalochistan = async () => {
    try {
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        const titleElements = $('tbody > tr > th + td');
        const cities = [];
        titleElements.each((idx, el) => {
            let cityValue = $(el).text();
            let currentIndex = 0;
            let city = '';
            let stop = false;
            while (currentIndex < cityValue.length && stop == false) {
                if (cityValue[currentIndex] == '\n') {
                    stop = true;
                }
                if ((cityValue[currentIndex].charCodeAt(0) >= 'a'.charCodeAt(0) && cityValue[currentIndex].charCodeAt(0) <= 'z'.charCodeAt(0)) || (cityValue[currentIndex].charCodeAt(0) >= 'A'.charCodeAt(0) && cityValue[currentIndex].charCodeAt(0) <= 'Z'.charCodeAt(0)) && stop == false) {
                    city += cityValue[currentIndex];
                }
                currentIndex++;
            }
            if (city != '') {
                cities.push(city);
            }
            
        });
        return cities.slice(0, cities.length - 1);
    } catch(err) {
        console.log(err);
    }
}
exports.scrapeCitiesOfBalochistan = scrapeCitiesOfBalochistan;