const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');

const url = 'https://www.fmc.com.pk/list-of-cities-in-punjab-pakistan';

// this scrape cities of punjab 
// store them in array 
const scrapeCitiesOfPunjab = async () => {
    try {
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        const titleElements = $('td > ul li');
        const cities = [];
        titleElements.each((idx, el) => {
            cities.push($(el).text());
        });
        return cities;
    } catch(err) {
        console.log(err);
    }
}
exports.scrapeCitiesOfPunjab = scrapeCitiesOfPunjab;