const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');

const url = 'https://en.wikipedia.org/wiki/List_of_cities_in_Sindh';

// this scrape cities of sindh 
// store them in array 
const scrapeCitiesOfSindh = async () => {
    try {
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        const titleElements = $('table > tbody > tr');
        const cities = [];
        titleElements.each((idx, el) => {
            let cityValue = $(el).text();
            cityValue = cityValue.slice(cityValue.indexOf('\n') + 1);
            cityValue = cityValue.slice(cityValue.indexOf('\n') + 1);
            let currentIndex = 0;
            let city = '';
            let stop = false;
            while (currentIndex < cityValue.length && stop == false) {
                if (cityValue[currentIndex] == '\n') {
                    stop = true;
                }
                if ((cityValue[currentIndex].charCodeAt(0) >= 'a'.charCodeAt(0) && cityValue[currentIndex].charCodeAt(0) <= 'z'.charCodeAt(0)) || (cityValue[currentIndex].charCodeAt(0) >= 'A'.charCodeAt(0) && cityValue[currentIndex].charCodeAt(0) <= 'Z'.charCodeAt(0)) && stop == false) {
                    city += cityValue[currentIndex];
                }
                currentIndex++;
            }
            cities.push(city);
        });
        return cities.slice(1);
    } catch(err) {
        console.log(err);
    }
}
exports.scrapeCitiesOfSindh = scrapeCitiesOfSindh;